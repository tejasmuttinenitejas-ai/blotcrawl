-- Blot Search API — API key system
-- Run this AFTER schema.sql, in the same SQL Editor (New query)

create extension if not exists pgcrypto;

create table if not exists api_keys (
  id             bigserial primary key,
  key            text unique not null,
  label          text,                    -- who/what this key is for, e.g. "my website"
  requests_used  int default 0,
  monthly_limit  int default 1000,
  is_active      boolean default true,
  created_at     timestamptz default now()
);

-- Generates a random key like: blot_a1b2c3d4e5f6...
create or replace function generate_api_key() returns text as $$
  select 'blot_' || encode(gen_random_bytes(18), 'hex');
$$ language sql;

-- Issue yourself a first API key to test with.
-- After running this once, check the api_keys table to see your new key.
insert into api_keys (key, label) values (generate_api_key(), 'my first key');

-- Run this any time you want to issue a NEW key for someone else:
--   insert into api_keys (key, label) values (generate_api_key(), 'their label');
