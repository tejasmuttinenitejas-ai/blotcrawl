-- Blot search engine — Supabase schema
-- Run this once in Supabase Dashboard → SQL Editor → New query

-- ============================================================
-- PAGES: the index. One row per crawled page.
-- Kept deliberately lean (content is truncated) to fit far more
-- pages inside the 500MB free-tier database budget.
-- ============================================================
create table if not exists pages (
  id             bigserial primary key,
  url            text unique not null,
  title          text,
  description    text,
  content        text,                 -- cleaned, truncated body text (see crawler MAX_CONTENT_CHARS)
  domain         text,
  fetched_at     timestamptz,          -- null until actually crawled (vs. just discovered)
  inbound_links  int default 0,        -- simple popularity signal, bumped via bump_inbound()
  search_vector  tsvector generated always as (
                   setweight(to_tsvector('english', coalesce(title, '')), 'A') ||
                   setweight(to_tsvector('english', coalesce(description, '')), 'B') ||
                   setweight(to_tsvector('english', coalesce(content, '')), 'C')
                 ) stored
);

create index if not exists idx_pages_search on pages using gin (search_vector);
create index if not exists idx_pages_domain on pages (domain);

-- ============================================================
-- CRAWL_QUEUE: URLs waiting to be fetched (or already processed)
-- ============================================================
create table if not exists crawl_queue (
  id         bigserial primary key,
  url        text unique not null,
  status     text default 'pending',  -- pending | crawling | done | failed
  priority   int  default 0,
  attempts   int  default 0,
  added_at   timestamptz default now()
);

create index if not exists idx_queue_status on crawl_queue (status, priority desc, added_at);

-- ============================================================
-- bump_inbound: called when the crawler discovers links pointing
-- at a URL. Increments a popularity counter and creates a stub
-- pages row if that URL hasn't been crawled yet (so it already
-- has a starting rank once it IS crawled). This avoids storing
-- a full link-edge table, which would blow the storage budget
-- fast at any real scale.
-- ============================================================
create or replace function bump_inbound(urls text[]) returns void as $$
  insert into pages (url, inbound_links)
  select u, 1 from unnest(urls) as u
  on conflict (url) do update set inbound_links = pages.inbound_links + 1;
$$ language sql;

-- ============================================================
-- search_pages: the ranking function. Combines text relevance
-- (ts_rank_cd) with a log-scaled popularity boost from inbound
-- links — a simplified, storage-cheap stand-in for PageRank.
-- ============================================================
create or replace function search_pages(query text, limit_count int default 20)
returns table (
  url text,
  title text,
  description text,
  domain text,
  rank real,
  inbound_links int
) as $$
  select
    p.url,
    p.title,
    p.description,
    p.domain,
    ts_rank_cd(p.search_vector, websearch_to_tsquery('english', query))
      * (1 + ln(1 + p.inbound_links)) as rank,
    p.inbound_links
  from pages p
  where p.fetched_at is not null
    and p.search_vector @@ websearch_to_tsquery('english', query)
  order by rank desc
  limit limit_count;
$$ language sql stable;

-- ============================================================
-- Grants: the public search page uses Supabase's "anon" key, so
-- it needs explicit permission to call the search function.
-- (Required for all projects created after ~May 2026; harmless
-- to run on older projects too.)
-- ============================================================
grant usage on schema public to anon;
grant execute on function search_pages(text, int) to anon;
